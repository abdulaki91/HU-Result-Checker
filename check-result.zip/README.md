# Telegram Student Results Bot

A complete Telegram bot system for managing and checking student results using Node.js. Admins can upload Excel files containing student data, and students can query their results by sending their Student ID.

## Features

- 🤖 **Telegram Bot Integration** - Built with node-telegram-bot-api
- 📊 **Excel File Processing** - Upload and parse .xlsx/.xls files
- 🔍 **Student Result Lookup** - Students can check results by Student ID
- 👑 **Admin Controls** - Restricted file upload and system management
- 💾 **Flexible Storage** - MySQL or JSON file storage options
- 🛡️ **Security** - Admin-only upload access and input validation
- ⚡ **Real-time Processing** - Instant result lookup and file processing

## Excel File Format

The Excel file must contain these columns:

| STUDENT NAME | STUDENT ID | QUIZ | MID | ASSIGNMENT | FINAL | TOTAL | GRADE |
| ------------ | ---------- | ---- | --- | ---------- | ----- | ----- | ----- |
| John Doe     | ST001      | 85   | 78  | 92         | 88    | 343   | A     |
| Jane Smith   | ST002      | 90   | 82  | 88         | 91    | 351   | A     |

## Installation

1. **Clone or download the project**

   ```bash
   git clone <repository-url>
   cd telegram-student-results-bot
   ```

2. **Install dependencies**

   ```bash
   npm install
   ```

3. **Set up environment variables**

   ```bash
   cp .env.example .env
   ```

   Edit `.env` file with your configuration:

   ```env
   BOT_TOKEN=your_telegram_bot_token_here
   ADMIN_USER_ID=your_telegram_user_id_here
   DB_HOST=localhost
   DB_PORT=3306
   DB_NAME=student_results
   DB_USER=root
   DB_PASSWORD=your_mysql_password
   USE_JSON_STORAGE=false
   ```

4. **Get Telegram Bot Token**
   - Message [@BotFather](https://t.me/botfather) on Telegram
   - Create a new bot with `/newbot`
   - Copy the bot token to your `.env` file

5. **Get your Telegram User ID**
   - Message [@userinfobot](https://t.me/userinfobot) on Telegram
   - Copy your user ID to the `.env` file

## Configuration Options

### Database Storage

**Option 1: MySQL (Recommended)**

```env
USE_JSON_STORAGE=false
DB_HOST=localhost
DB_PORT=3306
DB_NAME=student_results
DB_USER=root
DB_PASSWORD=your_mysql_password
```

**Option 2: JSON File Storage**

```env
USE_JSON_STORAGE=true
```

### MySQL Setup

**Install MySQL:**

**Windows:**

- Download MySQL Community Server from https://dev.mysql.com/downloads/mysql/
- Install and start MySQL service
- Or use XAMPP/WAMP which includes MySQL

**macOS:**

```bash
brew install mysql
brew services start mysql
```

**Linux:**

```bash
sudo apt-get install mysql-server
sudo systemctl start mysql
```

**Setup Database:**

```bash
npm run setup-db
```

This will create the database, table, and insert sample data.

## Running the Bot

### Development Mode

```bash
npm run dev
```

### Production Mode

```bash
npm start
```

## Usage

### For Students

1. Start a chat with your bot
2. Send `/start` to see instructions
3. Send your Student ID (e.g., `ST001`) to get your results

### For Admins

1. Upload Excel file with student data
2. Use `/status` to check system status
3. Use `/help` for available commands

## Bot Commands

| Command   | Description                      | Access     |
| --------- | -------------------------------- | ---------- |
| `/start`  | Welcome message and instructions | Everyone   |
| `/help`   | Show help and available commands | Everyone   |
| `/status` | System status and student count  | Admin only |

## Project Structure

```
telegram-student-results-bot/
├── bot.js              # Main bot logic and message handling
├── config.js           # Configuration and environment variables
├── database.js         # Database operations (MySQL/JSON)
├── excelService.js     # Excel file parsing and validation
├── setup-database.js   # MySQL database setup script
├── package.json        # Dependencies and scripts
├── .env.example        # Environment variables template
├── .gitignore         # Git ignore rules
├── README.md          # This file
├── temp/              # Temporary file storage (auto-created)
└── data/              # JSON storage directory (auto-created)
```

## Database Schema

The MySQL table structure:

```sql
CREATE TABLE students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_name VARCHAR(255) NOT NULL,
  student_id VARCHAR(100) NOT NULL UNIQUE,
  quiz DECIMAL(5,2) NOT NULL,
  mid DECIMAL(5,2) NOT NULL,
  assignment DECIMAL(5,2) NOT NULL,
  final DECIMAL(5,2) NOT NULL,
  total DECIMAL(6,2) NOT NULL,
  grade VARCHAR(10) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_student_id (student_id)
);
```

## Error Handling

The bot includes comprehensive error handling for:

- Invalid Excel file formats
- Missing required columns
- Duplicate Student IDs
- Database connection issues
- File download failures
- Invalid user inputs

## Security Features

- **Admin-only uploads** - Only specified admin can upload files
- **Input validation** - All data is validated before storage
- **File cleanup** - Temporary files are automatically deleted
- **Error sanitization** - Sensitive errors are not exposed to users

## Troubleshooting

### Common Issues

1. **Bot not responding**
   - Check if BOT_TOKEN is correct
   - Verify bot is running (`npm start`)
   - Check console for error messages

2. **File upload fails**
   - Ensure you're the admin user
   - Check Excel file format and columns
   - Verify file is .xlsx or .xls

3. **Database connection issues**
   - For MySQL: Ensure MySQL is running and credentials are correct
   - For JSON: Check file permissions in data/ directory
   - Run `npm run setup-db` to initialize MySQL

4. **Student not found**
   - Verify Student ID format matches Excel file
   - Check if data was uploaded successfully
   - Use `/status` command to verify student count

### MySQL Connection Issues

```bash
# Test MySQL connection
mysql -u root -p -h localhost

# Check if MySQL is running (Windows)
net start | findstr MySQL

# Check if MySQL is running (Linux/macOS)
sudo systemctl status mysql
```

### Logs and Debugging

The bot provides detailed console logging:

- ✅ Success messages
- ❌ Error messages
- ⚠️ Warning messages
- 📝 Info messages

## Development

### Adding New Features

1. **New Commands** - Add to `setupCommands()` in `bot.js`
2. **Database Operations** - Extend `Database` class in `database.js`
3. **Excel Processing** - Modify `ExcelService` class in `excelService.js`

### Testing

Test the bot with sample data:

1. Run `npm run setup-db` to create sample data
2. Test student ID lookups with sample IDs (ST001, ST002, ST003)
3. Upload a test Excel file as admin
4. Verify error handling with invalid inputs

## Scripts

- `npm start` - Start the bot in production mode
- `npm run dev` - Start the bot in development mode with auto-restart
- `npm run setup-db` - Initialize MySQL database with sample data

## License

MIT License - feel free to use and modify for your needs.

## Support

For issues and questions:

1. Check the troubleshooting section
2. Review console logs for error details
3. Verify configuration in `.env` file
4. Test with sample data first
5. Ensure MySQL is running and accessible
