require("dotenv").config();

const config = {
  BOT_TOKEN: process.env.BOT_TOKEN,
  ADMIN_USER_ID: parseInt(process.env.ADMIN_USER_ID),
  DB_HOST: process.env.DB_HOST || "localhost",
  DB_PORT: parseInt(process.env.DB_PORT) || 3306,
  DB_NAME: process.env.DB_NAME || "student_results",
  DB_USER: process.env.DB_USER || "root",
  DB_PASSWORD: process.env.DB_PASSWORD || "",
  USE_JSON_STORAGE: process.env.USE_JSON_STORAGE === "true",
  JSON_FILE_PATH: "./data/students.json",
};

// Validate required environment variables
if (!config.BOT_TOKEN) {
  console.error("❌ BOT_TOKEN is required in .env file");
  process.exit(1);
}

if (!config.ADMIN_USER_ID) {
  console.error("❌ ADMIN_USER_ID is required in .env file");
  process.exit(1);
}

module.exports = config;
